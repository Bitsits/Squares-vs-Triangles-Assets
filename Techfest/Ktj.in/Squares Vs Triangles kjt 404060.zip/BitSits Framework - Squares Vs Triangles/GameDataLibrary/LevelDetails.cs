﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;

namespace GameDataLibrary
{
    public class LevelDetails
    {
        public int GameMode;

        public List<int> ArmyNumber;
    }
}
